<?php

//$name="h";
//$age=5;
$name=(string)readline("Как вас зовут?");
$age=(int)readline("Сколько вам лет?");

echo "Вас зовут $name, ваш возраст $age лет";


?>