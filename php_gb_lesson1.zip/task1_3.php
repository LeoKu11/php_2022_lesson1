<?php

$taskQuestion="Какая задача стоит перед вами сегодня?";
$timeQuestion="Сколько примерно времени эта задача займет?";

$name=readline("Как вас зовут?");

$task1=readline($taskQuestion);
$taskTime1=(int)readline($timeQuestion);

$task2=readline($taskQuestion);
$taskTime2=(int)readline($timeQuestion);

$task3=readline($taskQuestion);
$taskTime3=(int)readline($timeQuestion);

$totalTime=$taskTime1+$taskTime2+$taskTime3;

echo"
{$name}, сегодня у вас запланировано 3 приоритетных задачи на день:
-{$task1} ({taskTime1}ч)
-{$task2} ({taskTime2}ч)
-{$task3} ({taskTime3}ч)
Примерное выполнение плана = {$totalTime}ч
";

?>